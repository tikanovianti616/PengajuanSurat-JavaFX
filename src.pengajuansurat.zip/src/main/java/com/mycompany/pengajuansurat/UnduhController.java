package com.mycompany.pengajuansurat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.File;

public class UnduhController {

    @FXML private TextField txtCariKode;
    @FXML private Button btnCari;
    @FXML private Button btnDownloadPdf;
    @FXML private Button btnLoginSekre;

    @FXML
    public void initialize() {
        // Sembunyikan tombol download saat pertama kali dibuka
        if (btnDownloadPdf != null) {
            btnDownloadPdf.setVisible(false);
            btnDownloadPdf.setManaged(false);
        }
    }

    @FXML
    private void handleCariKode() {
        String kode = txtCariKode.getText().trim();

        if (kode.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Peringatan", "Silakan masukkan kode tracking terlebih dahulu!");
            return;
        }

        // Tampilkan tombol download jika pencarian berhasil
        btnDownloadPdf.setVisible(true);
        btnDownloadPdf.setManaged(true);
    }

    @FXML
    private void handleDownloadPdf() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Simpan File Surat");
        fileChooser.setInitialFileName("Surat_" + txtCariKode.getText().trim() + ".pdf");
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("PDF Files (*.pdf)", "*.pdf")
        );

        File file = fileChooser.showSaveDialog(btnDownloadPdf.getScene().getWindow());
        if (file != null) {
            showAlert(Alert.AlertType.INFORMATION, "Berhasil", "Surat berhasil diunduh ke:\n" + file.getAbsolutePath());
        }
    }

    @FXML
    private void handleLoginSekre() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/pengajuansurat/fxml/LoginView.fxml"));
            Parent root = loader.load();

            Stage loginStage = new Stage();
            loginStage.setTitle("Login Sekretaris");
            loginStage.setScene(new Scene(root));
            loginStage.initModality(Modality.APPLICATION_MODAL); 
            loginStage.setResizable(false);
            loginStage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Gagal membuka jendela Login: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}