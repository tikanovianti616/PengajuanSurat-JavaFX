package com.mycompany.pengajuansurat;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

public class PengajuanController {

    // Disesuaikan dengan fx:id di Scene Builder kamu (btnSubmit)
    @FXML private Button btnSubmit;

    // Disesuaikan dengan On Action di Scene Builder kamu (handleSubmit)
    @FXML
    private void handleSubmit() {
        showAlert(Alert.AlertType.INFORMATION, "Berhasil", "Pengajuan surat berhasil dikirim!");
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}