module com.mycompany.us2gether {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.pengajuansurat to javafx.fxml;
    exports com.mycompany.pengajuansurat;
}
